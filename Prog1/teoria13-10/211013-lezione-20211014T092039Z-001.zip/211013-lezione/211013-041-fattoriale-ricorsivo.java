/** OBIETTIVO.
  Dato n valore naturale, calcolare n!. 
  
  L'algoritmo seguente deriva dalla rilettura dell'evoluzione
  dei valori della variabile che accumula il risultato 'fattoriale'
  in un algoritmo iterativo che calcola n!:
  
  f_0 = 1            // riletto come f(0) = 1
  f_1 = n * f_0      // riletto come f(1) = 1 * f(0)
  f_2 = n * f_1      // riletto come f(2) = 2 * f(1)
  ...
  f_n = n * f_{n-1}  // riletto come f(n) = n * f(n-1)
*/
// ipotesi fattRic(2)
fattRic(n) {
  if (n == 0) { // caso base
    f = 1;
    return f
  } else { // caso induttivo
    f = n * fattRic(n - 1);
    return f
  }
}