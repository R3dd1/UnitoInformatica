/** OBIETTIVO
  Osservare l'evolversi delle configurazioni sul frame stack
  generato dalla JVM che interpreta il codice oggetto del
  seguente sorgente Java, usando Java Visualizer.   */

public class EsponenteConMoltiplicazione {
  
   public static void main(String[] args) {
     exp(2,2);
   }

   public static int exp(int a, int b) {
     int res = 1;
     int i = 0;
     while (i < b) {
       res = mul(res, a); 
       i = i + 1;
     }
     return res;
   }
   
   public static int mul(int a, int b) {
     int res = 0;
     int i = b;
     while (i > 0) {
       res = sum2(res, a);
       i = i - 1;
     }
     return res;
   }
   
   public static int sum2(int a, int b) {
     while (a > 0) {
       a = a - 1;
       b = b + 1;
     }
     return b;
   }
}