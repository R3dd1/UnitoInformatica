/** OBIETTIVO.
    Algoritmo che dati due valori nelle variabili x ed y
    restituisce il valore x^y calcolando 
    x^y = x * ... * x per y volte.
*/

/* --------------------------------------------- */
/* assumiamo x==2, y==3                          */
esp(x,y) { 
  e = 1;
  i = y;
  while (i > 0) { 
    e = mol(e, x);
    i = i - 1;
  }
  return m.
}

mol(x,y) {
  m = 0;
  i = y;
  while (i > 0) { 
    m = som(m, x);
    i = i - 1;
  }
  return m.
}

som(a,b) {
  s = a;
  i = b;
  while (i > 0) {  
    s = s + 1;
    i = i - 1;
  }
  return s.
}

/* DISPENSE.
   Ne tratta il Capitolo 3 in maniera molto più aderente 
   al linguaggio di programmazione di riferimento Java.    */