/** OBIETTIVO.
  Dati x e y valori naturali, calcolare il valore x+y. 
  
  L'algoritmo seguente deriva dalla rilettura dell'evoluzione
  dei valori della variabile che accumula il risultato 'somma'
  in un algoritmo iterativo che calcola x+y:
  
  s_0 = x        // riletto come s(x,0)
  s_1 = s_0 + 1  // riletto come s(x,1) = s(x,0) + 1
  s_2 = s_1 + 1  // riletto come s(x,2) = s(x,1) + 1
  ...
  s_n = s_{n-1} + 1  // riletto come s(x,n) = s(x,n-1) + 1
*/

piuRic(x, y) {
  if (y == 0) {
    s = x;
    return s
  } else {
    s = piuRic(x, y - 1) + 1;
    return s
  }
}

// devo risolvere piu(x,y)?
// assumo di saper risolvere piu(x,y-1) che è più semplice
// qusndo ho risolto piu(x,y-1) sommo 1 e ottnego la soluzione
// di piu(x,y).