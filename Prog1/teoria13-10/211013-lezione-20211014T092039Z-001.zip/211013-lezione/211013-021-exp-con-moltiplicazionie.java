/** OBIETTIVO.
    Algoritmo che dati due valori nelle variabili x ed y
    restituisce il valore x^y calcolando 
    x^y = x * ... * x per y volte.
*/

/* --------------------------------------------- */
/* assumiamo x==2, y==3                          */
// Il mondo chiama esp con parametri attuali 2 e 3.
// richiamiamo esp(2,3)
esp(x, y) {
  e = 1
  i = y
  while (i > 0) {
    e = mol(e, x)
    i = i - 1
  }
  return e
}
  
mol(x, y) {
  m = 0
  i = y
  while (i > 0) {
    m = som(m,x) 
    i = i - 1
  }
  return m
}

som(x, y) {
  s = x
  i = y
  while (i > 0) {
    s = s + 1 
    i = i - 1
  }
  return s
}


/* DISPENSE.
   Ne tratta il Capitolo 3 in maniera molto più aderente 
   al linguaggio di programmazione di riferimento Java.    */