#### Simulazione algebrica de `exp`

Quella che segue è una possibile rappresentazione compatta di come evolve il calcolo di $2$ elevato a $3$ per mezzo dell'algoritmo `exp`:

$$
\begin{align}
\texttt{exp}(2,3) & = ((1*2)*2)*2 \\
& = (((0+1)+1)*2)*2 \\
& = (2*2)*2 \\
& = ((0+2)+2)*2 \\
& = (4)*2 \\
& = (0+4)+4 \\
& = 8
\end{align}
$$

Vale la pena osservare che:

1. $\texttt{exp}(2,3)$ diventa $((1*2)*2)*2$ perché l'algoritmo che abbiamo scritto vede un esponenziale come iterazione di moltiplicazioni;
2. la riscrittura della sottoespressione $1*2$ nella espressione $ (0+1)+1 $  corrisponde al fatto che una moltiplicazione è vista come iterazione di incrementi;
3. la riscrittura della sottoespressione $ (0+1)+1 $ nella espressione $ 2 $  corrisponde al fatto che, ad un certo punto l'espressione $ (0+1)+1 $ è  trasformata nel valore che essa rappresenta.
